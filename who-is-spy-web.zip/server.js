import express from 'express';
import http from 'http';
import { WebSocketServer } from 'ws';
import crypto from 'crypto';

const app=express();
const server=http.createServer(app);
const wss=new WebSocketServer({server});
app.use(express.static('public'));
app.get('/health',(req,res)=>res.json({ok:true}));

const rooms=new Map();
const words=[
 ['ทะเล','สระว่ายน้ำ'],['โรงพยาบาล','คลินิก'],['สนามบิน','สถานีรถไฟ'],['สวนสัตว์','อควาเรียม'],
 ['โรงเรียน','มหาวิทยาลัย'],['ร้านอาหาร','คาเฟ่'],['โรงหนัง','โรงละคร'],['ห้างสรรพสินค้า','ตลาด'],
 ['ห้องสมุด','ร้านหนังสือ'],['สนามฟุตบอล','สนามบาส'],['ชายหาด','สวนน้ำ'],['โรงแรม','หอพัก'],
 ['สวนสนุก','สวนน้ำ'],['พิพิธภัณฑ์','แกลเลอรี'],['สถานีตำรวจ','สถานีดับเพลิง']
];
const id=()=>crypto.randomBytes(3).toString('hex').toUpperCase();
const roomCode=()=>{let x; do{x=id().slice(0,5)}while(rooms.has(x)); return x};
function send(ws,msg){if(ws?.readyState===1)ws.send(JSON.stringify(msg));}
function broadcast(room,msg){for(const p of room.players)send(p.ws,msg);}
function publicPlayers(room){return room.players.map(p=>({id:p.id,name:p.name,ready:p.ready,connected:!!p.ws}));}
function stateFor(room,p){
 return {type:'state',phase:room.phase,players:publicPlayers(room),hostId:room.hostId,
   roomCode:room.code,minPlayers:room.minPlayers,maxPlayers:room.maxPlayers,round:room.round,totalRounds:4,
   turn:room.turn,submissions:room.submissions,submissionCount:Object.keys(room.submissions).length, votes:Object.keys(room.votes).length,selfId:p?.id||null,
   word:p?.word||null,isSpy:p?.isSpy??null,startedAt:room.startedAt};
}
function sync(room){for(const p of room.players)send(p.ws,stateFor(room,p));}
function startGame(room){
 if(room.players.length<room.minPlayers)return;
 room.phase='countdown'; sync(room);
 setTimeout(()=>{
   const [civil,spy]=words[Math.floor(Math.random()*words.length)];
   const spyIndex=Math.floor(Math.random()*room.players.length);
   room.players.forEach((p,i)=>{p.isSpy=i===spyIndex;p.word=p.isSpy?spy:civil;p.ready=false;});
   room.phase='playing';room.round=1;room.turn=0;room.submissions={};room.votes={};room.startedAt=Date.now();sync(room);
 },5000);
}
function nextRound(room){
 if(room.round>=4){room.phase='voting';room.votes={};sync(room);return;}
 room.round++;room.turn=0;room.submissions={};sync(room);
}
function reveal(room){
 const tally={};for(const v of Object.values(room.votes))tally[v]=(tally[v]||0)+1;
 const max=Math.max(...Object.values(tally),0);const picked=Object.entries(tally).filter(([,n])=>n===max).map(([k])=>k);
 const spies=room.players.filter(p=>p.isSpy).map(p=>p.id);
 const spyCaught=spies.some(s=>picked.includes(s));
 room.result={spyCaught,tally,picked,spies,spyWord:room.players.find(p=>p.isSpy)?.word||''};room.phase='result';sync(room);
}
function reset(room){room.phase='lobby';room.round=0;room.turn=0;room.submissions={};room.votes={};room.result=null;room.players.forEach(p=>{p.ready=false;p.word=null;p.isSpy=null});sync(room);}

wss.on('connection',ws=>{
 ws.on('message',raw=>{
  let m;try{m=JSON.parse(raw)}catch{return};
  let room=rooms.get(m.roomCode);
  if(m.type==='create'){
   const code=roomCode();room={code,minPlayers:3,maxPlayers:5,hostId:null,phase:'lobby',players:[],round:0,turn:0,submissions:{},votes:{},result:null};rooms.set(code,room);
   const p={id:crypto.randomUUID(),name:String(m.name||'Player').slice(0,18),ws,ready:false};room.hostId=p.id;room.players.push(p);ws.pid=p.id;ws.room=code;sync(room);return;
  }
  if(!room)return send(ws,{type:'error',message:'ไม่พบห้อง'});
  if(m.type==='join'){
   if(room.phase!=='lobby')return send(ws,{type:'error',message:'เกมเริ่มไปแล้ว'});
   if(room.players.length>=room.maxPlayers)return send(ws,{type:'error',message:'ห้องเต็ม'});
   const p={id:crypto.randomUUID(),name:String(m.name||'Player').slice(0,18),ws,ready:false};room.players.push(p);ws.pid=p.id;ws.room=room.code;sync(room);return;
  }
  const p=room.players.find(x=>x.id===ws.pid);if(!p)return;
  if(m.type==='ready'&&room.phase==='lobby'){p.ready=!!m.value;sync(room);if(room.players.length>=room.minPlayers&&room.players.every(x=>x.ready))startGame(room);}
  else if(m.type==='start'&&p.id===room.hostId&&room.phase==='lobby')startGame(room);
  else if(m.type==='submit'&&room.phase==='playing'&&m.text?.trim()){
    if(room.turn!==room.players.findIndex(x=>x.id===p.id))return;
    room.submissions[p.id]=String(m.text).slice(0,160);room.turn++;
    if(room.turn>=room.players.length)nextRound(room); else sync(room);
  }
  else if(m.type==='vote'&&room.phase==='voting'&&room.players.some(x=>x.id===m.targetId)){room.votes[p.id]=m.targetId;if(Object.keys(room.votes).length===room.players.length)reveal(room);else sync(room);}
  else if(m.type==='playAgain'&&room.phase==='result'&&p.id===room.hostId)reset(room);
 });
 ws.on('close',()=>{
  const room=rooms.get(ws.room);if(!room)return;const p=room.players.find(x=>x.id===ws.pid);if(p)p.ws=null;sync(room);
 });
});

const port=process.env.PORT||3000;server.listen(port,()=>console.log(`Who Is Spy running on ${port}`));
