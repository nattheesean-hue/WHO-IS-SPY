# WHO IS SPY?

A real-time 3–5 player web game. 4 rounds of player-written clues, secret words, voting, and reveal.

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

## Deploy
Deploy this folder to any Node.js host that supports WebSockets. Set the start command to `npm start` and use the host's public URL. HTTPS is recommended because the browser will then use secure WebSockets automatically.

## Important
The current version stores active rooms in server memory. Restarting the server clears active rooms. This is intentional for the first playable version; persistent accounts/database can be added later.
